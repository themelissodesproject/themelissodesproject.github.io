Data table: M. appressus location and distribution

Compiled by: Hogland, F. E. published on The Melissodes Project.
License: CC BY 4.0
Updated: 28 November 2025
Contact: frank@wildref.org

Note: Data is compiled from GBIF (Secretariat 2023).

Citation: Hogland, F. E. (2025). Melissodes agilis. The Melissodes Project. Latest version available at https://themelissodesproject.wildref.org/melissodes-agilis.html. Permanent archived version: Zenodo. https://doi.org/10.5281/zenodo.17502133

When citing this data, please also cite:

GBIF.org (24 November 2025) GBIF Occurrence Download, DOI available at time of access: https://doi.org/10.15468/dl.mqr3nm. Archive preserved at Zenodo: https://doi.org/10.5281/zenodo.17705791
