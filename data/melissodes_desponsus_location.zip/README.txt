Data table: M. desponsus location and distribution

Compiled by: Hogland, F. E. published on The Melissodes Project.
License: CC BY 4.0
Updated: 22 November 2025
Contact: frank@wildref.org

Note: Data is compiled from Discover Life (Ascher & Pickering 2025) and GBIF (Secretariat 2023).

Citation: Hogland, F. E. (2025). Melissodes agilis. The Melissodes Project. Latest version available at https://themelissodesproject.wildref.org/melissodes-agilis.html. Permanent archived version: Zenodo. https://doi.org/10.5281/zenodo.17502133

When citing this data, please also cite:

Ascher, J.S. & Pickering, J. (2025). Discover Life bee species guide and world checklist (Hymenoptera: Apoidea: Anthophila): Data records. Discover Life. Available at: https://www.discoverlife.org/mp/20q?guide=Apoidea_species (Accessed 18 November 2025).

GBIF.org (18 November 2025) GBIF Occurrence Download, DOI available at time of access: https://doi.org/10.15468/dl.eru7c3. Archive preserved at Zenodo: https://doi.org/10.5281/zenodo.17643992
