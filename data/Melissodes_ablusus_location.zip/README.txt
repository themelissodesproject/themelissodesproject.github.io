Data table: M. agilis location and distribution

Compiled by: Hogland, F. E. published on The Melissodes Project.
License: CC BY 4.0
Updated: 11 November 2025
Contact: frank@wildref.org

Note: Data compiled from GBIF (Secretariat, 2023), Wilson, J.S. et al. (2025), and DeBano, S.J. et al, (2024).

Citation: Hogland, F. E. (2025). Melissodes ablusus. The Melissodes Project. Latest version available at https://themelissodesproject.wildref.org/Melissodes-Ablusus.html.

