===========================================================
Dataset: Melissodes ablusus occurrence records
===========================================================

Compiled by: The Melissodes Project (2025)
Maintainer: F. E. Hogland
Website: https://themelissodesproject.wildref.org/Melissodes-Ablusus.html
Last updated: 11 November 2025
File format: CSV
License: CC BY 4.0 (Attribution)

-----------------------------------------------------------
Description
-----------------------------------------------------------
This dataset contains occurrence records of Melissodes ablusus
compiled by Hogland, F. E. published on The Melissodes Project. 
Records were transcribed and standardized from GBIF 
(GBIF Secretariat 2023) and supplemented with 
locality information derived from 
Wilson et al. (2025) and DeBano et al. (2024).

All coordinates have been verified manually for consistency and 
accuracy; records lacking coordinates are excluded.

-----------------------------------------------------------
Citation
-----------------------------------------------------------
GBIF Secretariat (2023). *GBIF Backbone Taxonomy.* Checklist dataset.
https://doi.org/10.15468/39omei (Accessed via GBIF.org on 10 September 2025).

If using this dataset, please also cite:

Hogland, F. E. (2025). Melissodes ablusus. The Melissodes Project. Latest version available at https://themelissodesproject.wildref.org/Melissodes-Ablusus.html.

-----------------------------------------------------------
Usage and attribution
-----------------------------------------------------------
These data are made available under the Creative Commons Attribution 4.0 
International License (CC BY 4.0). Users are free to share and adapt the 
dataset for any purpose, provided proper attribution is given to the 
original sources listed above.

-----------------------------------------------------------
Contact
-----------------------------------------------------------
For questions, corrections, or updates:
Email: frank@wildref.org
Project: The Melissodes Project
Website: https://themelissodesproject.wildref.org
===========================================================
