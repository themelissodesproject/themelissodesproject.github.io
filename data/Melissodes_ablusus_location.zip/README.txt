Data table: M. ablusus location and distribution

Compiled by: Hogland, F. E. published on The Melissodes Project.
License: CC BY 4.0
Updated: 01 November 2025
Contact: frank@wildref.org

Note: Data compiled from GBIF (Secretariat, 2023), Wilson, J.S. et al. (2025), and DeBano, S.J. et al, (2024).

Citation: Hogland, F. E. (2025). Melissodes ablusus. The Melissodes Project. Latest version available at https://themelissodesproject.wildref.org/Melissodes-Ablusus.html.

When citing this data, please also cite: 

GBIF Secretariat (2023). GBIF Backbone Taxonomy. Checklist dataset 
https://doi.org/10.15468/39omei accessed via GBIF.org on 2025-11-01. 
Data retrieved for Melissodes ablusus Cockerell, 1926.

Wilson, J.S. et al. (2025) ‘A checklist of the Bees of Utah’, 
Diversity, 17(3), p. 212. doi:10.3390/d17030212.

DeBano, S.J., H. Schmalz, M.M. Rowland, J. Fields, P. Schreder and 
C. Duquette. 2024. Managing and Restoring Pollinator Habitat in 
Interior Pacific Northwest Grasslands and Riparian Areas. Available 
at: https://www.oregon.gov/oweb/data-reporting/HP/Pages/zumwalt-prairie.aspx