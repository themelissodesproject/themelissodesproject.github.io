Data table: M. bicoloratus location and distribution

Compiled by: Hogland, F. E. published on The Melissodes Project.
License: CC BY 4.0
Updated: 10 December 2025
Contact: frank@wildref.org

Note: Data is compiled from GBIF (Secretariat 2023).

Citation: Hogland, F. E. (2025). Melissodes bicoloratus. The Melissodes Project. Latest version available at https://themelissodesproject.wildref.org/melissodes-bicoloratus.html.

When citing this data, please also cite:

GBIF.org (3 December 2025) GBIF Occurrence Download, DOI available at time of access: https://doi.org/10.15468/dl.cqrdzy. Archive preserved at Zenodo: https://doi.org/10.5281/zenodo.17808936
